# VRBox Home OS V2

Um "Home OS" próprio para VR Box + celular, inspirado em conceitos públicos de
interfaces de realidade virtual e mixed reality, mas sem copiar software,
código, marcas ou assets proprietários.

## Visão

A V2 mistura ideias úteis que existem na família Quest:
- ambiente Home persistente;
- passthrough;
- hand tracking;
- menus rápidos;
- janelas flutuantes;
- painel de pesquisa;
- configuração de sala;
- anchors;
- área de proteção;
- modo VR estéreo;
- fallback para controles físicos;
- perfis de capacidade por dispositivo.

No celular, o ambiente físico é capturado pela câmera traseira e o app desenha
elementos virtuais sobre ele. O MediaPipe fornece os landmarks da mão.

## Compatibilidade

### VR Box + celular
É o alvo principal deste projeto. O celular funciona como câmera + tela.

### Quest 3 / Quest 3S
A arquitetura também separa o "backend de câmera" do resto da aplicação.
Em uma futura build Android/Quest, o backend pode ser trocado por APIs nativas.

### Quest 2
O perfil evita assumir color passthrough ou scene mesh avançado. Recursos
dependentes desses sensores ficam em modo simulado/indisponível.

## Instalação no PC para teste

```bash
python -m venv .venv

# Windows
.venv\Scripts\activate

# Linux/macOS
# source .venv/bin/activate

pip install -r requirements.txt
python main.py
```

## Testar a câmera
Abra `config.json` e deixe:

```json
"camera_source": 0
```

ou use uma URL MJPEG:

```json
"camera_source": "http://192.168.1.10:8080/video"
```

## Controles
- `ESC`: sair
- `M`: menu Home
- `Q`: Quick Settings
- `P`: passthrough
- `H`: ligar/desligar hand tracking
- `G`: área de proteção
- `R`: iniciar calibração da sala
- `N`: nova janela web
- `B`: abrir URL da janela selecionada no navegador do sistema
- `TAB`: trocar janela selecionada
- `F5`: salvar casa
- `F9`: carregar casa
- `SPACE`: colocar móvel
- `DELETE`: remover móvel selecionado

## Gestos
- indicador aponta para uma janela ou móvel;
- polegar + indicador em pinça = selecionar/arrastar;
- palma aberta = cursor ativo;
- gesto de pinça no botão Home abre uma interação contextual.

## O que é diferente de simplesmente "colar Quest"
A V2 tem uma camada `CapabilityProfile`. Assim podemos ter:
- VR Box Phone;
- Quest 2;
- Quest 3;
- Quest 3S.

A interface usa a mesma experiência, mas cada backend habilita somente o
que aquele hardware realmente oferece.

## Próxima etapa recomendada
Migrar a camada visual para OpenXR/Unity ou Godot para obter:
- profundidade estereoscópica real;
- head tracking;
- occlusion;
- anchors espaciais persistentes;
- WebView 3D;
- APK Android.
