# VR Box Home OS V6 OpenXR

Home OS Android para VR Box usando câmera traseira, estéreo, MediaPipe e uma camada OpenXR.

## Recursos

- câmera traseira adaptativa;
- passthrough para o ambiente real;
- modo estéreo para VR Box;
- hand tracking com MediaPipe;
- pinça para clicar e arrastar;
- menu de palma;
- janelas web flutuantes;
- Guardian visual;
- giroscópio para estabilização/estado de movimento;
- áudio espacial;
- ponte nativa OpenXR;
- salvamento das preferências da casa;
- build do APK sem Android Studio.

## OpenXR

O projeto usa o loader oficial OpenXR para Android 1.1.62 da Khronos. O loader procura o
runtime ativo pelo mecanismo oficial do Android OpenXR. Se houver runtime compatível, o
Home OS tenta inicializar uma instância OpenXR; caso não haja, o modo VR Box próprio continua
funcionando.

Isso é propositalmente diferente de fingir que o loader é um runtime. Um runtime OpenXR completo
precisa implementar a API OpenXR e ser registrado pelo Runtime Broker. O pacote ainda não é um
runtime completo para transformar qualquer telefone em um headset universal.

## Build no Windows, sem Android Studio

Abra a pasta do projeto e execute:

`tools\\BUILD_APK.bat`

O script baixa as Command Line Tools do Android, instala SDK/Build Tools/NDK e baixa o Gradle
necessário. No final, o APK aparece em:

`app\\build\\outputs\\apk\\debug\\app-debug.apk`

Não existe mais script de WhatsApp, Wi-Fi, compartilhamento automático ou envio para telefone.

## Limites de jogos externos

Roblox VR, Gorilla Tag VR e outros jogos OpenXR precisam de um runtime OpenXR real no dispositivo.
O Home OS não altera um APK Android normal para virar automaticamente uma experiência OpenXR.
A integração correta de jogos externos é feita através do runtime, quando o dispositivo oferece
esse runtime.


## FINAL COMPLETE
Esta versão reúne o Home OS, câmera adaptativa, MediaPipe, gesto por mãos, Guardian, janelas WebView, PC/Game Hub, OpenXR bridge e catálogo com 32 móveis.

Roblox VR: o botão Roblox VR abre o aplicativo Roblox instalado, mas a própria Roblox documenta a experiência VR oficial para Meta Quest/PC VR. Como não existe uma API pública para transformar o Roblox Android comum em VR de mãos, o projeto não injeta código no Roblox. citeturn876255search0turn876255search2
