﻿$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

# Force UTF-8 for PowerShell output where supported.
try { [Console]::OutputEncoding = [System.Text.UTF8Encoding]::new() } catch {}

$base = Join-Path $env:USERPROFILE '.vrbox-android'
$sdk = Join-Path $base 'sdk'
$cmdlineRoot = Join-Path $sdk 'cmdline-tools'
$latest = Join-Path $cmdlineRoot 'latest'
$sm = Join-Path $latest 'bin\sdkmanager.bat'
$zip = Join-Path $base 'commandlinetools-win-15859902_latest.zip'
$tmp = Join-Path $base 'cmdline_tmp'

New-Item -ItemType Directory -Force -Path $base | Out-Null
New-Item -ItemType Directory -Force -Path $cmdlineRoot | Out-Null

function Remove-IfExists([string]$path) {
    if (Test-Path -LiteralPath $path) {
        Remove-Item -LiteralPath $path -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function Download-File([string]$url, [string]$outFile) {
    Remove-IfExists $outFile
    Write-Host "Baixando: $url"
    $curl = Get-Command curl.exe -ErrorAction SilentlyContinue
    if ($curl) {
        & $curl.Source '-L' '--fail' '--retry' '8' '--retry-all-errors' '--retry-delay' '2' '-o' $outFile $url
        if ($LASTEXITCODE -ne 0) { throw "curl falhou com código $LASTEXITCODE" }
    } else {
        Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $outFile
        if ($LASTEXITCODE -ne 0) { throw "Invoke-WebRequest falhou com código $LASTEXITCODE" }
    }
    if (!(Test-Path -LiteralPath $outFile)) { throw 'Download não criou o arquivo.' }
    $len = (Get-Item -LiteralPath $outFile).Length
    if ($len -lt 100000000) { throw "Download parece incompleto: $len bytes." }
}

function Find-SdkManager([string]$root) {
    $candidates = @(
        (Join-Path $root 'bin\sdkmanager.bat'),
        (Join-Path $root 'cmdline-tools\latest\bin\sdkmanager.bat'),
        (Join-Path $root 'cmdline-tools\bin\sdkmanager.bat')
    )
    foreach ($c in $candidates) {
        if (Test-Path -LiteralPath $c) { return (Get-Item -LiteralPath $c).FullName }
    }
    $found = Get-ChildItem -LiteralPath $root -Filter 'sdkmanager.bat' -File -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($null -ne $found) { return $found.FullName }
    return $null
}

# If a previous run extracted the tools somewhere unexpected, reuse them.
$existing = Find-SdkManager $sdk
if ($null -ne $existing -and $existing -ne $sm) {
    Write-Host "sdkmanager encontrado em: $existing"
    Remove-IfExists $latest
    New-Item -ItemType Directory -Force -Path $latest | Out-Null
    $srcDir = Split-Path $existing -Parent
    Copy-Item -LiteralPath (Join-Path $srcDir '*') -Destination $latest -Recurse -Force
}

if (!(Test-Path -LiteralPath $sm)) {
    Write-Host '[1/3] Baixando Android Command Line Tools...'
    $url = 'https://dl.google.com/android/repository/commandlinetools-win-15859902_latest.zip'
    $expectedSha256 = '90ae805d20434428bffcb699c290860f19bb5f66a67e6b330067e3de801fb04a'

    Download-File $url $zip

    try {
        $actualSha256 = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actualSha256 -ne $expectedSha256) {
            throw "SHA-256 inválido. Esperado: $expectedSha256 / recebido: $actualSha256"
        }

        Remove-IfExists $tmp
        New-Item -ItemType Directory -Force -Path $tmp | Out-Null
        Expand-Archive -LiteralPath $zip -DestinationPath $tmp -Force

        $found = Find-SdkManager $tmp
        if ($null -eq $found) {
            throw "sdkmanager.bat não foi encontrado dentro do ZIP. Conteúdo extraído: $((Get-ChildItem -LiteralPath $tmp -Recurse -File | Select-Object -First 10 -ExpandProperty FullName) -join '; ')"
        }

        $source = Split-Path $found -Parent
        $sourceRoot = Split-Path $source -Parent
        if (!(Test-Path (Join-Path $sourceRoot 'bin\sdkmanager.bat'))) {
            $sourceRoot = $source
        }

        if (!(Test-Path (Join-Path $sourceRoot 'bin\sdkmanager.bat'))) {
            throw "Estrutura inesperada no ZIP. sdkmanager encontrado em: $found"
        }

        Remove-IfExists $latest
        New-Item -ItemType Directory -Force -Path $latest | Out-Null
        Copy-Item -LiteralPath (Join-Path $sourceRoot '*') -Destination $latest -Recurse -Force
    }
    catch {
        Remove-IfExists $tmp
        Remove-IfExists $zip
        throw "Falha ao preparar Android Command Line Tools: $($_.Exception.Message)"
    }

    Remove-IfExists $tmp
    Remove-IfExists $zip
}

if (!(Test-Path -LiteralPath $sm)) {
    throw "sdkmanager.bat não foi encontrado em $sm"
}

Write-Host '[1/3] Instalando componentes do Android SDK...'
& $sm --sdk_root=$sdk 'platform-tools' 'platforms;android-36' 'build-tools;36.0.0' 'ndk;27.2.12479018'
if ($LASTEXITCODE -ne 0) { throw "sdkmanager falhou com código $LASTEXITCODE" }

Write-Host "Android SDK pronto em $sdk"
