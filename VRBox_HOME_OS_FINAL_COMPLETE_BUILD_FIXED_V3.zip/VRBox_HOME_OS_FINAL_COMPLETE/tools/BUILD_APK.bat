@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>&1
cd /d %~dp0..

echo ========================================
echo VR BOX HOME OS - BUILD APK
echo ========================================
echo [1/3] Preparando Android SDK...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0bootstrap_android.ps1"
if errorlevel 1 goto :fail

echo [2/3] Preparando Gradle...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0bootstrap_gradle.ps1"
if errorlevel 1 goto :fail

echo [3/3] Compilando APK...
set "GRADLE=%USERPROFILE%\.vrbox-android\gradle\gradle-9.5\bin\gradle.bat"
set "ANDROID_HOME=%USERPROFILE%\.vrbox-android\sdk"
set "ANDROID_SDK_ROOT=%ANDROID_HOME%"
if not exist "%GRADLE%" goto :gradle_missing
"%GRADLE%" --no-daemon --stacktrace assembleDebug
if errorlevel 1 goto :fail

echo.
echo ========================================
echo APK GERADO COM SUCESSO
echo ========================================
echo %CD%\app\build\outputs\apk\debug\app-debug.apk
echo.
pause
exit /b 0

:gradle_missing
echo Gradle nao foi encontrado. Rode novamente.
goto :fail

:fail
echo.
echo ========================================
echo ERRO NO BUILD
echo ========================================
echo Verifique a mensagem acima para identificar a etapa que falhou.
echo.
pause
exit /b 1
