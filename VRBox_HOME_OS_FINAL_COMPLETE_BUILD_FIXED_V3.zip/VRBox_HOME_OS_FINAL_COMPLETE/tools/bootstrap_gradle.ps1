$ErrorActionPreference = 'Stop'
$base = Join-Path $env:USERPROFILE '.vrbox-android'
$dir = Join-Path $base 'gradle'
$gradleHome = Join-Path $dir 'gradle-9.5'
New-Item -ItemType Directory -Force -Path $dir | Out-Null

if (!(Test-Path (Join-Path $gradleHome 'bin\gradle.bat'))) {
    $zip = Join-Path $dir 'gradle-9.5-bin.zip'
    $url = 'https://services.gradle.org/distributions/gradle-9.5-bin.zip'
    Write-Host 'Baixando Gradle 9.5...'
    Invoke-WebRequest -Uri $url -OutFile $zip
    if (Test-Path $gradleHome) { Remove-Item $gradleHome -Recurse -Force }
    Expand-Archive -Force $zip $dir
    Remove-Item $zip -Force
}

Write-Host "Gradle instalado em $gradleHome"
