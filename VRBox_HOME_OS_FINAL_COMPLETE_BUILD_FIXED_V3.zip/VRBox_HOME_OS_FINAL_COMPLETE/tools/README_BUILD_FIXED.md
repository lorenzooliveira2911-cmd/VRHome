# BUILD FIXED V2

Use uma extração nova deste ZIP. O bootstrap agora usa o pacote oficial Android Command Line Tools 15859902 e localiza sdkmanager.bat de forma recursiva.
