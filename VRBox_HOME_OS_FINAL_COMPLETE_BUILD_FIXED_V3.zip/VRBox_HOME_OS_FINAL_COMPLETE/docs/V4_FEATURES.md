# Histórico técnico da V6

A V6 deriva da V4 e mantém a camada de câmera, MediaPipe e UI espacial.

## Correções feitas

- Removido o código antigo de compartilhamento por Wi-Fi.
- Removidos scripts com nomes de envio/compartilhamento.
- Troca de `java.nio.file.Files.readAllBytes` por `File.readBytes()` para manter compatibilidade com API 24+.
- Leitura dos frames RGBA do CameraX corrigida para respeitar `rowStride` e `pixelStride`.
- Kotlin Gradle Plugin atualizado para 2.3.21, combinação documentada para AGP 9.3.0.
- OpenXR Loader atualizado para 1.1.62.
- Ponte OpenXR verifica `XR_KHR_android_create_instance` antes de ativá-la.
- Build Windows passou a usar a distribuição Gradle baixada pelo próprio script, eliminando a dependência de `gradlew.bat`/wrapper jar ausente.
- Workflow do GitHub Actions atualizado para Gradle 9.5 e SDK/NDK necessários.
