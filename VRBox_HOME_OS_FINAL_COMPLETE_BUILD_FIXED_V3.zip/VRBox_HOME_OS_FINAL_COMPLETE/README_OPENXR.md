# VR Box Home OS V6 OpenXR

## O que foi corrigido

- Removidos todos os scripts de compartilhamento por Wi-Fi/WhatsApp.
- Removido o caminho que tentava enviar automaticamente o APK para o celular.
- Corrigido o carregamento do modelo MediaPipe para funcionar desde API 24.
- Corrigida a leitura de frames RGBA do CameraX respeitando `rowStride` e `pixelStride`.
- A ponte OpenXR verifica a extensão Android antes de ativá-la.
- O ciclo de vida do loader/instância OpenXR é encerrado no `onDestroy`.
- Loader OpenXR atualizado para 1.1.62.

## OpenXR de verdade

O aplicativo contém o **loader OpenXR oficial da Khronos** e uma ponte nativa Android.
Ele tenta localizar um runtime OpenXR instalado no aparelho e, quando existe, cria uma
instância usando `XR_KHR_android_create_instance`.

Um app Android comum não pode simplesmente virar um runtime OpenXR completo só com um
loader: o runtime precisa implementar a API OpenXR e ser descoberto pelo Runtime Broker.
A própria especificação da Khronos define esse mecanismo de descoberta por ContentProvider
+ serviço de runtime. Portanto, nesta versão a aplicação é um **cliente OpenXR + fallback
VR Box próprio**, não um runtime falso que quebra jogos.

## Mãos

No VR Box de celular, o rastreamento continua vindo de câmera traseira + MediaPipe. Em um
runtime OpenXR que forneça `XR_EXT_hand_tracking`, o app também pode usar os joints OpenXR.

## Build sem Android Studio

No Windows, rode apenas:

`tools\\BUILD_APK.bat`

Isso prepara as ferramentas Android e compila o APK. Não há mais nenhum script de Wi-Fi,
enviar para telefone ou compartilhamento automático neste projeto.

## Importante para jogos VR externos

Roblox VR/Gorilla Tag VR precisam de uma sessão OpenXR real e de um runtime compatível com
o dispositivo. O nosso Home OS pode servir como experiência OpenXR, mas não transforma a
versão Android normal desses jogos em VR. Para isso, o próximo componente seria um runtime
OpenXR completo para o telefone, algo que é uma implementação grande e independente do Home OS.
