# Limite atual do runtime OpenXR

O pacote contém um **cliente OpenXR + loader + bridge nativa**.

Um runtime OpenXR completo é uma camada diferente. Na arquitetura oficial Android, o runtime
precisa expor sua biblioteca nativa como runtime e ser localizado pelo Runtime Broker. A biblioteca
precisa implementar as funções OpenXR usadas pelos aplicativos, sessões, spaces, views, swapchains,
inputs e o ciclo de eventos.

Para o VR Box de celular, o app atual usa a câmera e o MediaPipe diretamente como fallback. Isso evita
instalar um runtime incompleto que faria jogos externos simplesmente falharem.

A próxima etapa de runtime real exige uma implementação gráfica OpenGL ES/Vulkan + 3DoF/6DoF +
`XR_EXT_hand_tracking`/bindings + apresentação estéreo e registro via Runtime Broker.
