package com.vrbox.home

import android.Manifest
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.params.StreamConfigurationMap
import android.os.Bundle
import android.os.SystemClock
import android.util.Log
import android.util.Size
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.webkit.WebSettings
import android.webkit.WebView
import android.widget.FrameLayout
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.activity.ComponentActivity
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.MPImage
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : ComponentActivity(), VRHomeView.Listener, SensorEventListener {

    companion object {
        private const val CAMERA_REQUEST = 42
        private const val TAG = "VRBOX"
        private const val HAND_MODEL_URL =
            "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"
    }

    private lateinit var root: FrameLayout
    private lateinit var vrView: VRHomeView
    private lateinit var prefs: SharedPreferences
    private lateinit var analysisExecutor: ExecutorService
    private lateinit var hudManager: HudManager
    private lateinit var doubleTapDetector: DoubleTapDetector
    private lateinit var audio: SpatialAudioManager

    private var handLandmarker: HandLandmarker? = null
    private val webViews = HashMap<Int, Pair<WebView, WebView>>()

    private var sensorManager: SensorManager? = null
    private var gyroMagnitudeSmoothed = 0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestImmersive()
        prefs = getSharedPreferences("house", MODE_PRIVATE)

        root = FrameLayout(this)
        vrView = VRHomeView(this)
        vrView.listener = this
        root.addView(vrView, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        root.viewTreeObserver.addOnGlobalLayoutListener { syncWindowLayout() }

        vrView.guardian = prefs.getBoolean("guardian", true)
        vrView.furnitureCount = prefs.getInt("furniture", 32).coerceIn(0, 32)

        analysisExecutor = Executors.newSingleThreadExecutor()
        audio = SpatialAudioManager(this)

        val openXrStatus = OpenXrBridge.probe(this)
        vrView.setStatus(openXrStatus)
        vrView.pushToast(openXrStatus)

        hudManager = HudManager(this) { state -> runOnUiThread { vrView.setHud(state) } }
        hudManager.start()

        doubleTapDetector = DoubleTapDetector(this) {
            runOnUiThread {
                vrView.togglePassthrough()
                audio.playOpen(0f)
                vrView.pushToast(if (vrView.isPassthrough()) "Passthrough ativado" else "Ambiente virtual")
            }
        }
        doubleTapDetector.start()

        sensorManager = getSystemService(SENSOR_SERVICE) as? SensorManager
        sensorManager?.getDefaultSensor(Sensor.TYPE_GYROSCOPE)?.let {
            sensorManager?.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), CAMERA_REQUEST)
        } else {
            startCamera()
        }
    }

    private fun requestImmersive() {
        val w: Window = window
        w.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        @Suppress("DEPRECATION")
        w.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            )
    }

    // ===================== Câmera + MediaPipe =====================

    private fun startCamera() {
        loadHandModelThenStart()

        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                provider.unbindAll()

                val selector = CameraSelector.DEFAULT_BACK_CAMERA
                val cameraInfo = provider.availableCameraInfos.firstOrNull { info ->
                    runCatching {
                        Camera2CameraInfo.from(info).getCameraCharacteristic(CameraCharacteristics.LENS_FACING) ==
                            CameraCharacteristics.LENS_FACING_BACK
                    }.getOrDefault(false)
                } ?: provider.availableCameraInfos.first()

                val captureSize = chooseBestPhoneSize(cameraInfo)

                val analysisBuilder = ImageAnalysis.Builder()
                    .setTargetResolution(captureSize)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)

                val interop = Camera2Interop.Extender(analysisBuilder)
                interop.setCaptureRequestOption(
                    CameraCharacteristics.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE
                )
                interop.setCaptureRequestOption(
                    CameraCharacteristics.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON
                )
                interop.setCaptureRequestOption(
                    CameraCharacteristics.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO
                )

                val analysis = analysisBuilder.build()
                analysis.setAnalyzer(analysisExecutor) { proxy -> analyzeFrame(proxy) }

                provider.bindToLifecycle(this, selector, analysis)

                runOnUiThread {
                    vrView.setCameraInfo("Câmera adaptativa · ${captureSize.width}×${captureSize.height}")
                }
            } catch (e: Exception) {
                vrView.setStatus("Erro na câmera: ${e.javaClass.simpleName}")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun chooseBestPhoneSize(cameraInfo: androidx.camera.core.CameraInfo): Size {
        return try {
            val map: StreamConfigurationMap? = Camera2CameraInfo.from(cameraInfo)
                .getCameraCharacteristic(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                ?: return Size(1920, 1080)

            val sizes = map.getOutputSizes(ImageFormat.YUV_420_888) ?: return Size(1920, 1080)
            var best = sizes.firstOrNull() ?: return Size(1920, 1080)
            var bestArea = -1L

            for (s in sizes) {
                val ratio = s.width / s.height.toDouble()
                val usable = ratio in 1.55..1.82
                val area = s.width.toLong() * s.height
                if (usable && area > bestArea && area <= 3840L * 2160L) {
                    best = s
                    bestArea = area
                }
            }
            best
        } catch (e: Exception) {
            Log.w(TAG, "Could not query camera sizes", e)
            Size(1920, 1080)
        }
    }

    private fun loadHandModelThenStart() {
        analysisExecutor.execute {
            try {
                val modelFile = File(cacheDir, "hand_landmarker.task")
                if (!modelFile.exists() || modelFile.length() < 1_000_000) {
                    val conn = (URL(HAND_MODEL_URL).openConnection() as HttpURLConnection).apply {
                        connectTimeout = 15000
                        readTimeout = 30000
                    }
                    conn.connect()
                    conn.inputStream.use { input ->
                        FileOutputStream(modelFile).use { out ->
                            val buf = ByteArray(64 * 1024)
                            var n: Int
                            while (input.read(buf).also { n = it } != -1) out.write(buf, 0, n)
                        }
                    }
                    conn.disconnect()
                }
                setupHandLandmarker(modelFile)
                runOnUiThread { vrView.setStatus("Mãos prontas · pinça para selecionar") }
            } catch (e: Exception) {
                runOnUiThread { vrView.setStatus("Falha ao carregar o modelo de mãos: ${e.message}") }
            }
        }
    }

    private fun setupHandLandmarker(modelFile: File) {
        try {
            val modelBytes = modelFile.readBytes()
            val direct = ByteBuffer.allocateDirect(modelBytes.size)
            direct.put(modelBytes)
            direct.flip()

            val base = BaseOptions.builder()
                .setModelAssetBuffer(direct)
                .setDelegate(Delegate.GPU)
                .build()

            val options = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(base)
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setNumHands(2)
                .setMinHandDetectionConfidence(0.45f)
                .setMinHandPresenceConfidence(0.45f)
                .setMinTrackingConfidence(0.45f)
                .setResultListener { result, _ ->
                    runOnUiThread {
                        vrView.setHandStates(GestureEngine.process(result))
                        syncWindowLayout()
                    }
                }
                .setErrorListener { error ->
                    runOnUiThread { vrView.setStatus("Mãos: ${error.message}") }
                }
                .build()

            handLandmarker = HandLandmarker.createFromOptions(this, options)
        } catch (e: Exception) {
            vrView.setStatus("MediaPipe não iniciou: ${e.message}")
        }
    }

    private fun analyzeFrame(proxy: ImageProxy) {
        var bitmap: Bitmap? = null
        try {
            bitmap = rgbaBitmapFromProxy(proxy)
            // O frame do CameraX chega paisagem aqui. Espelha para interação natural em VR.
            val matrix = Matrix().apply { preScale(-1f, 1f) }
            val mirrored = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
            bitmap.recycle()
            bitmap = null

            runOnUiThread { vrView.setFrame(mirrored) }

            handLandmarker?.let { landmarker ->
                val analysisW = 720
                val analysisH = maxOf(1, Math.round(mirrored.height * (analysisW / mirrored.width.toFloat())))
                val handBitmap = Bitmap.createScaledBitmap(mirrored, analysisW, analysisH, true)
                val image: MPImage = BitmapImageBuilder(handBitmap).build()
                landmarker.detectAsync(image, SystemClock.uptimeMillis())
            }
        } catch (e: Exception) {
            Log.w(TAG, "Falha processando frame", e)
            bitmap?.recycle()
        } finally {
            proxy.close()
        }
    }

    private fun rgbaBitmapFromProxy(proxy: ImageProxy): Bitmap {
        val plane = proxy.planes.firstOrNull() ?: error("Frame sem plano RGBA")
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val width = proxy.width
        val height = proxy.height
        val rowBytes = width * 4

        if (pixelStride == 4 && rowStride == rowBytes) {
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val buffer = plane.buffer.duplicate()
            buffer.rewind()
            bitmap.copyPixelsFromBuffer(buffer)
            return bitmap
        }

        val pixels = IntArray(width * height)
        val bytes = plane.buffer.duplicate()
        val limit = bytes.limit()

        for (y in 0 until height) {
            val base = y * rowStride
            for (x in 0 until width) {
                val i = base + x * pixelStride
                if (i < 0 || i + 3 >= limit) continue

                val r = bytes.get(i).toInt() and 0xff
                val g = bytes.get(i + 1).toInt() and 0xff
                val b = bytes.get(i + 2).toInt() and 0xff
                val a = bytes.get(i + 3).toInt() and 0xff
                pixels[y * width + x] =
                    (a shl 24) or (r shl 16) or (g shl 8) or b
            }
        }

        return Bitmap.createBitmap(
            pixels,
            width,
            height,
            Bitmap.Config.ARGB_8888
        )
    }

    // ===================== Janelas espaciais (multi-WebView) =====================

    private fun createWebView(): WebView {
        val w = WebView(this)
        w.setBackgroundColor(Color.rgb(13, 16, 23))
        val s: WebSettings = w.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.setSupportZoom(false)
        s.builtInZoomControls = false
        return w
    }

    private fun openNewWindow() {
        val win = vrView.windowManager.open("https://www.google.com") ?: run {
            vrView.pushToast("Limite de janelas atingido")
            return
        }
        val left = createWebView()
        val right = createWebView()
        left.loadUrl(win.url)
        right.loadUrl(win.url)
        root.addView(left, FrameLayout.LayoutParams(1, 1))
        root.addView(right, FrameLayout.LayoutParams(1, 1))
        webViews[win.id] = left to right
        audio.playOpen(0f)
        vrView.pushToast("Janela aberta")
        syncWindowLayout()
    }

    private fun closeWindow(id: Int) {
        webViews.remove(id)?.let { (l, r) ->
            root.removeView(l); l.destroy()
            root.removeView(r); r.destroy()
        }
        audio.playClose(0f)
    }

    private fun closeAllWindows() {
        vrView.windowManager.windows.map { it.id }.forEach { id ->
            vrView.windowManager.close(id)
            closeWindow(id)
        }
    }

    /** Reposiciona as WebViews reais para casarem com o estado de [SpatialWindowManager]. */
    private fun syncWindowLayout() {
        val rootW = root.width
        val rootH = root.height
        if (rootW <= 10 || rootH <= 10) return
        val eyeW = rootW / 2
        val eyeH = rootH

        for (win in vrView.windowManager.windows) {
            val pair = webViews[win.id] ?: continue
            val r = win.rect(eyeW.toFloat(), eyeH.toFloat())
            val panelW = r.width().toInt().coerceAtLeast(1)
            val panelH = r.height().toInt().coerceAtLeast(1)

            val leftParams = FrameLayout.LayoutParams(panelW, panelH)
            leftParams.leftMargin = r.left.toInt()
            leftParams.topMargin = r.top.toInt()
            val rightParams = FrameLayout.LayoutParams(panelW, panelH)
            rightParams.leftMargin = eyeW + r.left.toInt()
            rightParams.topMargin = r.top.toInt()

            pair.first.layoutParams = leftParams
            pair.second.layoutParams = rightParams
        }
    }

    private fun saveHouse() {
        prefs.edit()
            .putInt("furniture", vrView.furnitureCount)
            .putBoolean("guardian", vrView.guardian)
            .apply()
        vrView.pushToast("Casa salva")
    }

    // ===================== VRHomeView.Listener =====================

    override fun onDockAction(action: DockAction) {
        when (action) {
            DockAction.HOME -> { closeAllWindows(); vrView.pushToast("Casa") }
            DockAction.FURNITURE -> vrView.pushToast("Catálogo de móveis")
            DockAction.GAMES -> {
                val robloxState = if (RobloxVrBridge.isInstalled(this)) "Roblox instalado" else "Roblox não instalado"
                vrView.pushToast("Game Hub · $robloxState")
                // Abrimos Roblox diretamente por pinça no botão JOGOS.
                if (RobloxVrBridge.isInstalled(this)) {
                    vrView.pushToast(RobloxVrBridge.launch(this))
                }
            }
            DockAction.GUARDIAN_TOGGLE -> {
                vrView.setGuardian(!vrView.guardian)
                vrView.pushToast(if (vrView.guardian) "Proteção ligada" else "Proteção desligada")
            }
            DockAction.NEW_WINDOW -> openNewWindow()
            DockAction.PASSTHROUGH_TOGGLE -> {
                vrView.togglePassthrough()
                vrView.pushToast(if (vrView.isPassthrough()) "Passthrough ativado" else "Ambiente virtual")
            }
            DockAction.SAVE -> saveHouse()
            DockAction.CLOSE_ALL -> { closeAllWindows(); vrView.pushToast("Janelas fechadas") }
        }
        runOnUiThread { syncWindowLayout() }
    }

    override fun onPalmMenuAction(action: PalmMenuAction) {
        when (action) {
            PalmMenuAction.RECENTER -> vrView.pushToast("Recentralizado")
            PalmMenuAction.SCREENSHOT -> vrView.pushToast("Captura salva (simulada)")
            PalmMenuAction.GUARDIAN_TOGGLE -> {
                vrView.setGuardian(!vrView.guardian)
                vrView.pushToast(if (vrView.guardian) "Proteção ligada" else "Proteção desligada")
            }
            PalmMenuAction.PASSTHROUGH_TOGGLE -> {
                vrView.togglePassthrough()
                vrView.pushToast(if (vrView.isPassthrough()) "Passthrough ativado" else "Ambiente virtual")
            }
            PalmMenuAction.CLOSE_ALL -> { closeAllWindows(); vrView.pushToast("Janelas fechadas") }
            PalmMenuAction.EXIT -> finish()
        }
    }

    override fun onWindowClosed(id: Int) {
        closeWindow(id)
    }

    override fun onWindowContentClick(id: Int, fracX: Float, fracY: Float) {
        val pair = webViews[id] ?: return
        val js = String.format(
            Locale.US,
            "(function(){var e=document.elementFromPoint(%1\$.1f,%2\$.1f); if(e){e.click();}})();",
            fracX * pair.first.width, fracY * pair.first.height
        )
        pair.first.evaluateJavascript(js, null)
        pair.second.evaluateJavascript(js, null)
    }

    override fun onVolumeAdjust(delta: Int) {
        hudManager.adjustVolume(delta)
    }

    // ===================== Sensores (movimento de cabeça aproximado p/ Guardian) =====================

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type == Sensor.TYPE_GYROSCOPE) {
            val magnitude = Math.abs(event.values[0]) + Math.abs(event.values[1]) + Math.abs(event.values[2])
            gyroMagnitudeSmoothed = gyroMagnitudeSmoothed * 0.85f + (magnitude / 6f) * 0.15f
            vrView.setHeadMotion(gyroMagnitudeSmoothed)
        }
    }

    override fun onAccuracyChanged(sensor: android.hardware.Sensor?, accuracy: Int) {}

    // ===================== Ciclo de vida =====================

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_REQUEST && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            startCamera()
        } else {
            vrView.setStatus("A câmera traseira é necessária para o Home OS.")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        hudManager.stop()
        doubleTapDetector.stop()
        sensorManager?.unregisterListener(this)
        analysisExecutor.shutdownNow()
        handLandmarker?.close()
        OpenXrBridge.shutdown()
        webViews.values.forEach { (l, r) -> l.destroy(); r.destroy() }
    }
}
