package com.vrbox.home

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.SystemClock
import kotlin.math.abs

/**
 * Detecta dois toques rápidos na carcaça da VR Box usando o giroscópio:
 * cada toque físico no gabinete gera um pico curto e brusco de velocidade
 * angular. Se dois picos ocorrerem dentro de [doubleTapWindowMs], dispara
 * [onDoubleTap] — usado para alternar passthrough sem precisar de gesto de mão.
 *
 * Threshold e janela são heurísticos: ajuste [spikeThreshold] se disparar
 * sozinho durante movimento normal de cabeça, ou aumente se estiver insensível.
 */
class DoubleTapDetector(
    context: Context,
    private val spikeThreshold: Float = 6.5f,
    private val minGapMs: Long = 60,
    private val doubleTapWindowMs: Long = 550,
    private val onDoubleTap: () -> Unit
) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    private val gyroscope = sensorManager?.getDefaultSensor(Sensor.TYPE_GYROSCOPE)

    private var lastSpikeAt = 0L
    private var pendingFirstTapAt = 0L
    private var lastSampleAt = 0L

    fun start() {
        gyroscope?.let {
            sensorManager?.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    fun stop() {
        sensorManager?.unregisterListener(this)
    }

    fun isAvailable(): Boolean = gyroscope != null

    override fun onSensorChanged(event: SensorEvent) {
        val now = SystemClock.uptimeMillis()
        if (now - lastSampleAt < minGapMs) return
        lastSampleAt = now

        val magnitude = abs(event.values[0]) + abs(event.values[1]) + abs(event.values[2])
        if (magnitude < spikeThreshold) return

        // debounce: evita contar vários eventos do mesmo impacto físico como dois toques
        if (now - lastSpikeAt < 120) return
        lastSpikeAt = now

        if (pendingFirstTapAt == 0L) {
            pendingFirstTapAt = now
        } else {
            val gap = now - pendingFirstTapAt
            pendingFirstTapAt = 0L
            if (gap in 80..doubleTapWindowMs) {
                onDoubleTap()
            }
        }
    }

    override fun onAccuracyChanged(sensor: android.hardware.Sensor?, accuracy: Int) {}
}
