package com.vrbox.home

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.sin

/**
 * Efeitos sonoros de UI 100% sintetizados em runtime (sem arquivos de asset)
 * com panorâmica estéreo simples baseada na posição X do elemento na tela
 * (-1 = totalmente esquerda, +1 = totalmente direita), simulando "áudio
 * espacial" leve. Também dispara vibração curta ao confirmar uma pinça.
 */
class SpatialAudioManager(context: Context) {

    private val appContext = context.applicationContext
    private val sampleRate = 44100

    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= 31) {
        (appContext.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        appContext.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    /** Clique curto e discreto — hover/seleção de botão. */
    fun playHover(panX: Float) = playTone(freqHz = 720f, durationMs = 45, volume = 0.18f, panX = panX)

    /** Confirmação de pinça bem-sucedida — tom mais definido + vibração. */
    fun playConfirm(panX: Float) {
        playTone(freqHz = 1180f, durationMs = 70, volume = 0.30f, panX = panX)
        vibrate(28)
    }

    /** Abertura de painel/janela — dois tons ascendentes. */
    fun playOpen(panX: Float = 0f) {
        playTone(freqHz = 520f, durationMs = 55, volume = 0.22f, panX = panX)
        thread(isDaemon = true) {
            Thread.sleep(55)
            playTone(freqHz = 880f, durationMs = 70, volume = 0.22f, panX = panX)
        }
    }

    /** Fechamento — tom descendente curto. */
    fun playClose(panX: Float = 0f) = playTone(freqHz = 340f, durationMs = 90, volume = 0.20f, panX = panX)

    fun vibrate(ms: Long) {
        val v = vibrator ?: return
        if (Build.VERSION.SDK_INT >= 26) {
            v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            v.vibrate(ms)
        }
    }

    private fun playTone(freqHz: Float, durationMs: Int, volume: Float, panX: Float) {
        thread(isDaemon = true) {
            runCatching {
                val numSamples = (sampleRate * durationMs / 1000f).toInt()
                val buffer = ShortArray(numSamples * 2) // estéreo intercalado

                val pan = panX.coerceIn(-1f, 1f)
                val leftGain = min(1f, 1f - pan.coerceAtLeast(0f)) * volume
                val rightGain = min(1f, 1f + pan.coerceAtMost(0f)) * volume

                for (i in 0 until numSamples) {
                    val t = i / sampleRate.toDouble()
                    // envelope simples (fade-in/out) evita "click" de descontinuidade
                    val envelope = min(1.0, min(i / 200.0, (numSamples - i) / 200.0))
                    val sample = sin(2.0 * PI * freqHz * t) * envelope
                    val l = (sample * leftGain * Short.MAX_VALUE).toInt().toShort()
                    val r = (sample * rightGain * Short.MAX_VALUE).toInt().toShort()
                    buffer[i * 2] = l
                    buffer[i * 2 + 1] = r
                }

                val attrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                val format = AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build()

                val track = AudioTrack(
                    attrs, format, buffer.size * 2, AudioTrack.MODE_STATIC, AudioManagerCompatSessionId
                )
                track.write(buffer, 0, buffer.size)
                track.play()
                Thread.sleep(durationMs.toLong() + 30)
                track.release()
            }
        }
    }

    companion object {
        private const val AudioManagerCompatSessionId = android.media.AudioManager.AUDIO_SESSION_ID_GENERATE
    }
}
