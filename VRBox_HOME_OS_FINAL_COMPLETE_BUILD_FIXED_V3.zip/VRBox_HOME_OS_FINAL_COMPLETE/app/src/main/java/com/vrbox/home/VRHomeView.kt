package com.vrbox.home

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.View
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

enum class DockAction { HOME, FURNITURE, GAMES, GUARDIAN_TOGGLE, NEW_WINDOW, PASSTHROUGH_TOGGLE, SAVE, CLOSE_ALL }
enum class PalmMenuAction { RECENTER, SCREENSHOT, GUARDIAN_TOGGLE, PASSTHROUGH_TOGGLE, CLOSE_ALL, EXIT }

private data class ToastItem(val text: String, val createdAt: Long, val slot: Int)

/**
 * View única responsável por toda a apresentação estéreo (Side-by-Side) do
 * Home OS: passthrough/skybox, Guardian, HUD, dock, menu de palma, laser +
 * pinça, janelas espaciais (WebView chrome) e notificações flutuantes.
 *
 * A View NÃO acessa a câmera nem o MediaPipe diretamente — ela só recebe
 * dados prontos via os métodos `set*` chamados pela MainActivity.
 */
class VRHomeView(context: Context) : View(context) {

    interface Listener {
        fun onDockAction(action: DockAction)
        fun onPalmMenuAction(action: PalmMenuAction)
        fun onWindowClosed(id: Int)
        fun onWindowContentClick(id: Int, fracX: Float, fracY: Float)
        fun onVolumeAdjust(delta: Int)
    }

    var listener: Listener? = null
    val windowManager = SpatialWindowManager(maxWindows = 4)

    // ---- estado de apresentação ----
    private var frame: Bitmap? = null
    private var status = "Aponte sua mão para começar"
    private var cameraInfo = "Câmera adaptativa"
    private var passthrough = true
    var guardian = true
        private set
    var furnitureCount = 3
    private var handStates: List<HandState> = emptyList()
    private var hud = HudState()

    // ---- menu de palma ----
    private var palmMenuOpen = false
    private var palmAnchorX = 0.5f
    private var palmAnchorY = 0.3f
    private val palmMenuItems = listOf(
        "◎" to "Recentralizar", "◫" to "Captura", "▦" to "Proteção",
        "◐" to "Passthrough", "×" to "Fechar tudo", "⏻" to "Sair"
    )
    private val palmMenuActions = listOf(
        PalmMenuAction.RECENTER, PalmMenuAction.SCREENSHOT, PalmMenuAction.GUARDIAN_TOGGLE,
        PalmMenuAction.PASSTHROUGH_TOGGLE, PalmMenuAction.CLOSE_ALL, PalmMenuAction.EXIT
    )
    private var palmMenuHighlight = -1

    // ---- dock ----
    private val dockLabels = listOf("⌂", "▦", "🎮", "◇", "WEB", "↓", "×")
    private val dockNames = listOf("CASA", "MÓVEIS", "JOGOS", "PROTEÇÃO", "JANELA", "SALVAR", "FECHAR")
    private val dockActions = listOf(
        DockAction.HOME, DockAction.FURNITURE, DockAction.GAMES, DockAction.GUARDIAN_TOGGLE,
        DockAction.NEW_WINDOW, DockAction.SAVE, DockAction.CLOSE_ALL
    )
    private var selectedDockButton = -1

    // ---- interação (pinça) ----
    private enum class Mode { NONE, DRAG_WINDOW, RESIZE_WINDOW }
    private var mode = Mode.NONE
    private var wasPinching = false
    private var activeWindowId = -1

    // ---- móveis (modo casa) ----
    private var selectedFurniture = -1
    private val furniture = listOf(
        RectF(.06f, .52f, .17f, .64f), RectF(.19f, .58f, .29f, .67f), RectF(.31f, .49f, .38f, .59f),
        RectF(.41f, .55f, .52f, .67f), RectF(.55f, .52f, .65f, .63f), RectF(.68f, .55f, .78f, .66f),
        RectF(.80f, .47f, .91f, .58f), RectF(.10f, .69f, .22f, .77f), RectF(.24f, .70f, .32f, .80f),
        RectF(.35f, .68f, .46f, .78f), RectF(.49f, .70f, .59f, .79f), RectF(.62f, .69f, .72f, .79f),
        RectF(.75f, .67f, .85f, .78f), RectF(.86f, .63f, .95f, .73f), RectF(.04f, .31f, .14f, .43f),
        RectF(.16f, .34f, .25f, .46f), RectF(.27f, .28f, .37f, .40f), RectF(.39f, .30f, .49f, .42f),
        RectF(.51f, .29f, .60f, .40f), RectF(.63f, .30f, .72f, .41f), RectF(.74f, .28f, .82f, .39f),
        RectF(.84f, .32f, .94f, .44f), RectF(.03f, .78f, .12f, .88f), RectF(.15f, .80f, .25f, .90f),
        RectF(.28f, .79f, .38f, .89f), RectF(.41f, .80f, .51f, .90f), RectF(.54f, .81f, .64f, .90f),
        RectF(.67f, .80f, .77f, .89f), RectF(.80f, .79f, .90f, .89f), RectF(.91f, .80f, .98f, .89f),
        RectF(.05f, .17f, .14f, .28f), RectF(.17f, .18f, .28f, .28f)
    )

    // ---- toasts ----
    private val toasts = ArrayList<ToastItem>()

    // ---- guardian proximidade ----
    private var headMotion = 0f

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        setLayerType(LAYER_TYPE_HARDWARE, null)
        p.typeface = Typeface.create("sans", Typeface.NORMAL)
    }

    // ===================== API pública (chamada pela MainActivity) =====================

    fun setFrame(b: Bitmap) {
        val old = frame
        frame = b
        if (old != null && old !== b && !old.isRecycled) old.recycle()
        invalidate()
    }

    fun setStatus(s: String) { status = s; invalidate() }
    fun setCameraInfo(s: String) { cameraInfo = s; invalidate() }
    fun setHud(h: HudState) { hud = h; invalidate() }
    fun setHeadMotion(magnitude: Float) { headMotion = magnitude.coerceIn(0f, 1f) }

    fun isPassthrough(): Boolean = passthrough
    fun setPassthrough(on: Boolean) { passthrough = on; invalidate() }
    fun togglePassthrough() { passthrough = !passthrough; invalidate() }

    fun setGuardian(on: Boolean) { guardian = on; invalidate() }

    fun pushToast(text: String) {
        val usedSlots = toasts.map { it.slot }.toSet()
        val slot = (0..3).firstOrNull { it !in usedSlots } ?: 0
        toasts.removeAll { it.slot == slot }
        toasts.add(ToastItem(text, SystemClock.uptimeMillis(), slot))
        if (toasts.size > 4) toasts.removeAt(0)
        invalidate()
    }

    fun setHandStates(states: List<HandState>) {
        handStates = states
        processInteraction()
        invalidate()
    }

    // ===================== Interação =====================

    private fun processInteraction() {
        val palmHand = handStates.firstOrNull { it.isLeft && it.palmUp }
        palmMenuOpen = palmHand != null
        if (palmHand != null) {
            palmAnchorX = palmHand.wristX
            palmAnchorY = palmHand.wristY
        }

        val pointerHand = handStates.firstOrNull { it !== palmHand } ?: handStates.firstOrNull()
        if (pointerHand == null) {
            palmMenuHighlight = -1
            selectedDockButton = -1
            wasPinching = false
            return
        }

        val eyeW = (width / 2f).takeIf { it > 1f } ?: return
        val eyeH = height.toFloat().takeIf { it > 1f } ?: return
        val px = pointerHand.pointerX * eyeW
        val py = pointerHand.pointerY * eyeH
        val pinching = pointerHand.pinching
        val pinchOnset = pinching && !wasPinching

        if (palmMenuOpen) {
            palmMenuHighlight = hitPalmMenuItem(px, py, eyeW, eyeH)
            if (pinchOnset && palmMenuHighlight >= 0) {
                fireConfirm(px, eyeW)
                listener?.onPalmMenuAction(palmMenuActions[palmMenuHighlight])
            }
        } else {
            selectedDockButton = hitDockButton(px, py, eyeW, eyeH)

            when (mode) {
                Mode.DRAG_WINDOW -> {
                    if (pinching) windowManager.updateDrag(px, py, eyeW, eyeH)
                    else { windowManager.endDrag(); mode = Mode.NONE }
                }
                Mode.RESIZE_WINDOW -> {
                    if (pinching) windowManager.updateResize(px, py, eyeW, eyeH)
                    else { windowManager.endResize(); mode = Mode.NONE }
                }
                Mode.NONE -> {
                    if (pinchOnset) handlePinchOnset(px, py, eyeW, eyeH)
                }
            }
        }

        wasPinching = pinching
    }

    private fun handlePinchOnset(px: Float, py: Float, eyeW: Float, eyeH: Float) {
        // 1) botões do dock
        val dockHit = hitDockButton(px, py, eyeW, eyeH)
        if (dockHit >= 0) {
            fireConfirm(px, eyeW)
            listener?.onDockAction(dockActions[dockHit])
            return
        }
        // 2) chrome das janelas (fechar / redimensionar / arrastar / conteúdo)
        for (win in windowManager.windows.asReversed()) {
            val closeR = win.closeHandleRect(eyeW, eyeH)
            if (closeR.contains(px, py)) {
                fireConfirm(px, eyeW)
                listener?.onWindowClosed(win.id)
                windowManager.close(win.id)
                return
            }
            val resizeR = win.resizeHandleRect(eyeW, eyeH)
            if (resizeR.contains(px, py)) {
                fireConfirm(px, eyeW)
                windowManager.beginResize(win)
                mode = Mode.RESIZE_WINDOW
                activeWindowId = win.id
                return
            }
            val titleR = win.titleBarRect(eyeW, eyeH)
            if (titleR.contains(px, py)) {
                fireConfirm(px, eyeW)
                windowManager.beginDrag(win, px, py, eyeW, eyeH)
                mode = Mode.DRAG_WINDOW
                activeWindowId = win.id
                return
            }
            val bodyR = win.rect(eyeW, eyeH)
            if (bodyR.contains(px, py)) {
                fireConfirm(px, eyeW)
                windowManager.focus(win.id)
                val fracX = (px - bodyR.left) / bodyR.width()
                val fracY = (py - bodyR.top) / bodyR.height()
                listener?.onWindowContentClick(win.id, fracX, fracY)
                return
            }
        }
        // 3) mobília (modo casa, só clicável quando visível)
        if (passthrough) {
            for (i in furniture.indices) {
                if (i >= furnitureCount) continue
                val r = furniture[i]
                val px0 = RectF(r.left * eyeW, r.top * eyeH, r.right * eyeW, r.bottom * eyeH)
                if (px0.contains(px, py)) {
                    selectedFurniture = i
                    fireConfirm(px, eyeW)
                    pushToast("Móvel selecionado")
                    return
                }
            }
        }
    }

    private fun fireConfirm(px: Float, eyeW: Float) {
        val pan = (px / eyeW) * 2f - 1f
        AudioSingleton.get(context).playConfirm(pan)
    }

    private fun hitDockButton(x: Float, y: Float, eyeW: Float, eyeH: Float): Int {
        val cy = eyeH * .90f
        val size = eyeH * .042f
        val n = dockLabels.size
        for (i in 0 until n) {
            val fx = 0.5f / n + i / n.toFloat()
            val cx = eyeW * fx
            if (hypot((x - cx).toDouble(), (y - cy).toDouble()) < size * 1.35) return i
        }
        return -1
    }

    private fun hitPalmMenuItem(x: Float, y: Float, eyeW: Float, eyeH: Float): Int {
        val cx0 = palmAnchorX * eyeW
        val cy0 = palmAnchorY * eyeH
        val radius = eyeH * 0.13f
        for (i in palmMenuItems.indices) {
            val ang = (Math.PI * 2 * i / palmMenuItems.size) - Math.PI / 2
            val ix = cx0 + (radius * Math.cos(ang)).toFloat()
            val iy = cy0 + (radius * Math.sin(ang)).toFloat()
            if (hypot((x - ix).toDouble(), (y - iy).toDouble()) < eyeH * 0.045) return i
        }
        return -1
    }

    // ===================== Desenho =====================

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat()
        val h = height.toFloat()
        val left = RectF(0f, 0f, w / 2f, h)
        val right = RectF(w / 2f, 0f, w, h)

        drawEnvironment(c, left, -1f)
        drawEnvironment(c, right, 1f)

        drawGuardian(c, left)
        drawGuardian(c, right)

        if (passthrough) {
            drawFurniture(c, left)
            drawFurniture(c, right)
        }

        drawWindowsChrome(c, left)
        drawWindowsChrome(c, right)

        drawDock(c, left)
        drawDock(c, right)

        drawHud(c, left)
        drawHud(c, right)

        drawRaysAndPointers(c, left, -1f)
        drawRaysAndPointers(c, right, 1f)

        if (palmMenuOpen) {
            drawPalmMenu(c, left)
            drawPalmMenu(c, right)
        }

        drawStatusText(c)
        drawToasts(c, w, h)
    }

    private fun drawEnvironment(c: Canvas, eye: RectF, shift: Float) {
        val f = frame
        if (passthrough && f != null && !f.isRecycled) {
            val fw = f.width.toFloat(); val fh = f.height.toFloat()
            val src = RectF(0f, 0f, fw, fh)
            val crop = fw * 0.015f
            if (shift > 0) src.left += crop else src.right -= crop
            p.alpha = 255
            c.drawBitmap(f, src, eye, p)
            p.color = Color.argb(55, 0, 0, 0)
            c.drawRect(eye, p)
        } else {
            drawSkybox(c, eye)
        }
    }

    private fun drawSkybox(c: Canvas, eye: RectF) {
        p.shader = LinearGradient(
            eye.left, eye.top, eye.left, eye.bottom,
            UiTheme.skyTop, UiTheme.skyBottom, Shader.TileMode.CLAMP
        )
        c.drawRect(eye, p)
        p.shader = null

        // grade procedural de horizonte (sem imagens/assets — 100% código)
        val t = (SystemClock.uptimeMillis() % 6000L) / 6000f
        p.color = UiTheme.skyGrid
        p.strokeWidth = 1.5f
        val horizonY = eye.top + eye.height() * 0.62f
        val lines = 10
        for (i in 0..lines) {
            val fx = (i / lines.toFloat() + t * 0.15f) % 1f
            val x = eye.left + fx * eye.width()
            c.drawLine(x, horizonY, eye.left + eye.width() * 0.5f, eye.bottom, p)
        }
        var yy = horizonY
        var step = 14f
        while (yy < eye.bottom) {
            c.drawLine(eye.left, yy, eye.right, yy, p)
            yy += step
            step *= 1.16f
        }
        // "estrelas" acima do horizonte, posições determinísticas
        p.color = Color.argb(150, 220, 230, 255)
        for (i in 0 until 40) {
            val sx = eye.left + ((i * 97) % 100) / 100f * eye.width()
            val sy = eye.top + ((i * 53) % 100) / 100f * (horizonY - eye.top) * 0.9f
            val tw = (sin((SystemClock.uptimeMillis() / 400f) + i) + 1f) / 2f
            p.alpha = (90 + tw * 120).toInt()
            c.drawCircle(sx, sy, 1.6f, p)
        }
        p.alpha = 255
    }

    private fun drawGuardian(c: Canvas, eye: RectF) {
        if (!guardian) return
        val l = eye.left + eye.width() * .08f
        val r = eye.right - eye.width() * .08f
        val t = eye.top + eye.height() * .30f
        val b = eye.bottom - eye.height() * .10f
        val bounds = RectF(l, t, r, b)

        val edgeProximity = nearestHandEdgeProximity(eye, bounds)
        val pulsePhase = (sin(SystemClock.uptimeMillis() / 260.0) + 1.0) / 2.0
        val alert = max(edgeProximity, headMotion * 0.4f)
        val col = blendColor(UiTheme.guardianCalm, UiTheme.guardianAlert, alert)

        p.style = Paint.Style.STROKE
        p.strokeWidth = 4f + alert * 5f
        p.color = UiTheme.withAlpha(col, (140 + pulsePhase * 60).toInt().coerceIn(0, 255))
        c.drawRoundRect(bounds, 28f, 28f, p)

        if (alert > 0.12f) {
            // grade de aviso reforçada perto da borda mais próxima da mão
            p.strokeWidth = 2f
            p.color = UiTheme.withAlpha(col, (alert * 160).toInt().coerceIn(0, 255))
            val cells = 6
            for (i in 1 until cells) {
                val fx = i / cells.toFloat()
                c.drawLine(bounds.left + fx * bounds.width(), bounds.top, bounds.left + fx * bounds.width(), bounds.bottom, p)
            }
            for (i in 1 until 4) {
                val fy = i / 4f
                c.drawLine(bounds.left, bounds.top + fy * bounds.height(), bounds.right, bounds.top + fy * bounds.height(), p)
            }
        }
        p.style = Paint.Style.FILL
    }

    private fun nearestHandEdgeProximity(eye: RectF, bounds: RectF): Float {
        var best = 0f
        for (hand in handStates) {
            val px = eye.left + hand.pointerX * eye.width()
            val py = eye.top + hand.pointerY * eye.height()
            val distToEdge = minOf(minOf(px - bounds.left, bounds.right - px), minOf(py - bounds.top, bounds.bottom - py))
            val margin = bounds.width() * 0.16f
            val proximity = (1f - (distToEdge / margin)).coerceIn(0f, 1f)
            best = max(best, proximity)
        }
        return best
    }

    private fun blendColor(a: Int, b: Int, t: Float): Int {
        val tt = t.coerceIn(0f, 1f)
        val r = (Color.red(a) + (Color.red(b) - Color.red(a)) * tt).toInt()
        val g = (Color.green(a) + (Color.green(b) - Color.green(a)) * tt).toInt()
        val bl = (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * tt).toInt()
        return Color.rgb(r, g, bl)
    }

    private fun drawFurniture(c: Canvas, eye: RectF) {
        for (i in furniture.indices) {
            if (i >= furnitureCount) continue
            val n = furniture[i]
            val r = RectF(
                eye.left + n.left * eye.width(), eye.top + n.top * eye.height(),
                eye.left + n.right * eye.width(), eye.top + n.bottom * eye.height()
            )

            // Cada móvel tem uma silhueta simples, leve para o celular renderizar bem.
            when (i) {
                0 -> { // sofá
                    p.color = Color.rgb(111, 75, 66); c.drawRoundRect(r, 22f, 22f, p)
                    p.color = Color.rgb(92, 59, 51); c.drawRoundRect(RectF(r.left, r.top - 20, r.right, r.top + 22), 18f, 18f, p)
                }
                2, 14, 15, 17, 20, 27 -> { // plantas/lâmpadas/quadros
                    p.color = Color.rgb(128, 77, 42); c.drawRect(RectF(r.centerX()-10f, r.top+20f, r.centerX()+10f, r.bottom), p)
                    p.color = Color.rgb(58, 160, 88); c.drawOval(RectF(r.centerX()-32, r.top, r.centerX()+32, r.top+38), p)
                }
                3, 4, 13, 19, 25, 26, 29, 31 -> { // eletrônicos / móveis altos
                    p.color = Color.rgb(52, 58, 70); c.drawRoundRect(r, 12f, 12f, p)
                    p.color = UiTheme.accentDim; c.drawRoundRect(RectF(r.left+8, r.top+8, r.right-8, r.bottom-18), 7f, 7f, p)
                }
                6, 21, 23, 24, 28 -> { // armários/objetos verticais
                    p.color = Color.rgb(115, 82, 58); c.drawRoundRect(r, 10f, 10f, p)
                }
                else -> {
                    p.color = if (i % 3 == 0) Color.rgb(149, 103, 63) else Color.rgb(88, 104, 124)
                    c.drawRoundRect(r, 14f, 14f, p)
                    p.color = Color.argb(70, 255, 255, 255)
                    c.drawRect(RectF(r.left+6, r.top+6, r.right-6, r.top + r.height()*0.25f), p)
                }
            }

            if (i == selectedFurniture) {
                p.style = Paint.Style.STROKE
                p.strokeWidth = 4f
                p.color = UiTheme.accent
                c.drawRoundRect(r, 18f, 18f, p)
                p.style = Paint.Style.FILL
            }
        }
    }

    /** Painel "vidro fosco": várias camadas de alpha simulam o blur. */
    private fun drawGlassPanel(c: Canvas, r: RectF, corner: Float = UiTheme.CORNER_MD, highlightBorder: Boolean = false) {
        p.color = UiTheme.panelGlassShadow
        c.drawRoundRect(RectF(r.left + 3, r.top + 5, r.right + 3, r.bottom + 5), corner, corner, p)
        p.color = UiTheme.panelGlassBase
        c.drawRoundRect(r, corner, corner, p)
        p.color = UiTheme.panelGlassHighlight
        c.drawRoundRect(RectF(r.left, r.top, r.right, r.top + r.height() * 0.4f), corner, corner, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = if (highlightBorder) 2.4f else 1.4f
        p.color = if (highlightBorder) UiTheme.accentSoft else UiTheme.panelGlassRim
        c.drawRoundRect(r, corner, corner, p)
        p.style = Paint.Style.FILL
    }

    private fun drawDock(c: Canvas, eye: RectF) {
        val dock = RectF(
            eye.left + eye.width() * .03f, eye.bottom - eye.height() * .17f,
            eye.right - eye.width() * .03f, eye.bottom - eye.height() * .03f
        )
        drawGlassPanel(c, dock, UiTheme.CORNER_LG)

        val n = dockLabels.size
        for (i in 0 until n) {
            val fx = 0.5f / n + i / n.toFloat()
            val cx = eye.left + eye.width() * fx
            val cy = eye.bottom - eye.height() * .10f
            val active = i == selectedDockButton
            val toggled = (dockActions[i] == DockAction.GUARDIAN_TOGGLE && guardian) ||
                (dockActions[i] == DockAction.PASSTHROUGH_TOGGLE && passthrough)
            p.color = when {
                active -> UiTheme.accent
                toggled -> UiTheme.accentDim
                else -> Color.rgb(40, 48, 60)
            }
            c.drawCircle(cx, cy, eye.height() * .040f, p)
            p.color = if (active) Color.rgb(10, 16, 22) else UiTheme.textPrimary
            p.textAlign = Paint.Align.CENTER
            p.textSize = if (i == 3) 14f else 22f
            c.drawText(dockLabels[i], cx, cy + 7f, p)
            p.textSize = 9f
            p.color = UiTheme.textMuted
            c.drawText(dockNames[i], cx, eye.bottom - eye.height() * .032f, p)
        }
    }

    private fun drawHud(c: Canvas, eye: RectF) {
        val bar = RectF(eye.left + eye.width() * .06f, eye.top + eye.height() * .015f,
            eye.right - eye.width() * .06f, eye.top + eye.height() * .075f)
        drawGlassPanel(c, bar, UiTheme.CORNER_SM)

        p.textAlign = Paint.Align.LEFT
        p.color = UiTheme.textPrimary
        p.textSize = bar.height() * 0.42f
        c.drawText(hud.time, bar.left + 18f, bar.centerY() + bar.height() * 0.16f, p)

        // wifi
        val wifiX = bar.left + bar.width() * 0.42f
        p.color = if (hud.wifiConnected) UiTheme.accent else UiTheme.textMuted
        for (i in 0..2) {
            val rad = bar.height() * (0.14f + i * 0.10f)
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2.4f
            c.drawArc(RectF(wifiX - rad, bar.centerY() - rad * 0.2f, wifiX + rad, bar.centerY() + rad * 1.6f), 200f, 140f, false, p)
        }
        p.style = Paint.Style.FILL
        c.drawCircle(wifiX, bar.centerY() + bar.height() * 0.16f, 2.6f, p)

        // bateria
        val battX = bar.left + bar.width() * 0.62f
        val battW = bar.width() * 0.14f
        val battH = bar.height() * 0.34f
        val battR = RectF(battX, bar.centerY() - battH / 2, battX + battW, bar.centerY() + battH / 2)
        p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = UiTheme.textSecondary
        c.drawRoundRect(battR, 3f, 3f, p)
        c.drawRect(RectF(battR.right, battR.top + battH * 0.25f, battR.right + 4f, battR.bottom - battH * 0.25f), p)
        p.style = Paint.Style.FILL
        p.color = if (hud.charging) UiTheme.success else if (hud.batteryPct < 20) UiTheme.danger else UiTheme.textPrimary
        val fillW = (battW - 4f) * (hud.batteryPct / 100f)
        c.drawRoundRect(RectF(battR.left + 2f, battR.top + 2f, battR.left + 2f + fillW, battR.bottom - 2f), 2f, 2f, p)
        p.color = UiTheme.textSecondary
        p.textSize = bar.height() * 0.30f
        c.drawText("${hud.batteryPct}%", battR.right + 12f, bar.centerY() + bar.height() * 0.12f, p)

        // volume (mini slider) — toque nas setas ajusta via dock/gesto futuro; aqui é só leitura visual
        val volX = bar.right - bar.width() * 0.16f
        val volW = bar.width() * 0.12f
        p.color = UiTheme.textMuted
        c.drawRoundRect(RectF(volX, bar.centerY() - 3f, volX + volW, bar.centerY() + 3f), 3f, 3f, p)
        p.color = UiTheme.accent
        c.drawRoundRect(RectF(volX, bar.centerY() - 3f, volX + volW * hud.volumeFrac, bar.centerY() + 3f), 3f, 3f, p)
    }

    private fun drawWindowsChrome(c: Canvas, eye: RectF) {
        val eyeW = eye.width(); val eyeH = eye.height()
        for (win in windowManager.windows) {
            val body = RectF(
                eye.left + win.x * eyeW, eye.top + win.y * eyeH,
                eye.left + (win.x + win.w) * eyeW, eye.top + (win.y + win.h) * eyeH
            )
            val titleLocal = win.titleBarRect(eyeW, eyeH)
            val title = RectF(eye.left + titleLocal.left, eye.top + titleLocal.top, eye.left + titleLocal.right, eye.top + titleLocal.bottom)

            drawGlassPanel(c, title, UiTheme.CORNER_SM, highlightBorder = win.focused)
            p.color = UiTheme.textPrimary
            p.textAlign = Paint.Align.LEFT
            p.textSize = title.height() * 0.42f
            c.drawText("◐ ${win.title}", title.left + 14f, title.centerY() + title.height() * 0.16f, p)

            // botão fechar
            val closeLocal = win.closeHandleRect(eyeW, eyeH)
            val closeR = RectF(eye.left + closeLocal.left, eye.top + closeLocal.top, eye.left + closeLocal.right, eye.top + closeLocal.bottom)
            p.color = UiTheme.danger
            p.textAlign = Paint.Align.CENTER
            p.textSize = closeR.height() * 0.5f
            c.drawText("×", closeR.centerX(), closeR.centerY() + closeR.height() * 0.18f, p)

            // moldura do corpo (o conteúdo real é desenhado pela WebView por cima)
            p.style = Paint.Style.STROKE
            p.strokeWidth = if (win.focused) 2.6f else 1.4f
            p.color = if (win.focused) UiTheme.accentSoft else UiTheme.panelGlassRim
            c.drawRoundRect(body, UiTheme.CORNER_SM, UiTheme.CORNER_SM, p)
            p.style = Paint.Style.FILL

            // handle de resize
            val rzLocal = win.resizeHandleRect(eyeW, eyeH)
            val rzR = RectF(eye.left + rzLocal.left, eye.top + rzLocal.top, eye.left + rzLocal.right, eye.top + rzLocal.bottom)
            p.color = UiTheme.accentDim
            c.drawLine(rzR.left + 6, rzR.bottom - 4, rzR.right - 4, rzR.top + 6, p)
            c.drawLine(rzR.left + 14, rzR.bottom - 4, rzR.right - 4, rzR.top + 14, p)
        }
    }

    private fun drawPalmMenu(c: Canvas, eye: RectF) {
        val cx0 = eye.left + palmAnchorX * eye.width()
        val cy0 = eye.top + palmAnchorY * eye.height()
        val radius = eye.height() * 0.13f

        p.color = UiTheme.panelGlassBase
        c.drawCircle(cx0, cy0, radius + eye.height() * 0.05f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.6f; p.color = UiTheme.panelGlassRim
        c.drawCircle(cx0, cy0, radius + eye.height() * 0.05f, p)
        p.style = Paint.Style.FILL

        for (i in palmMenuItems.indices) {
            val ang = (Math.PI * 2 * i / palmMenuItems.size) - Math.PI / 2
            val ix = cx0 + (radius * Math.cos(ang)).toFloat()
            val iy = cy0 + (radius * Math.sin(ang)).toFloat()
            val hovered = i == palmMenuHighlight
            p.color = if (hovered) UiTheme.accent else Color.rgb(40, 48, 60)
            c.drawCircle(ix, iy, eye.height() * 0.038f, p)
            p.color = if (hovered) Color.rgb(10, 16, 22) else UiTheme.textPrimary
            p.textAlign = Paint.Align.CENTER
            p.textSize = eye.height() * 0.028f
            c.drawText(palmMenuItems[i].first, ix, iy + eye.height() * 0.010f, p)
        }
        p.color = UiTheme.textSecondary
        p.textSize = eye.height() * 0.022f
        c.drawText(
            if (palmMenuHighlight >= 0) palmMenuItems[palmMenuHighlight].second else "Menu de palma",
            cx0, cy0 + eye.height() * 0.008f, p
        )
    }

    private fun drawRaysAndPointers(c: Canvas, eye: RectF, shift: Float) {
        for (hand in handStates) {
            if (hand.isLeft && hand.palmUp) continue // mão do menu de palma não emite laser

            val ox = eye.left + hand.wristX * eye.width()
            val oy = eye.top + hand.wristY * eye.height()
            val px = eye.left + hand.pointerX * eye.width()
            val py = eye.top + hand.pointerY * eye.height()

            // laser: estende do wrist através da ponta do indicador até a borda
            val dx = hand.rayDirX; val dy = hand.rayDirY
            var ex = px; var ey = py
            var t = 0f
            while (ex in eye.left..eye.right && ey in eye.top..eye.bottom && t < 4000f) {
                ex += dx * 8f; ey += dy * 8f; t += 8f
            }

            p.color = UiTheme.withAlpha(UiTheme.accent, if (hand.pinching) 210 else 100)
            p.strokeWidth = if (hand.pinching) 3.2f else 1.6f
            c.drawLine(ox, oy, ex, ey, p)

            // cursor na ponta do dedo
            p.color = UiTheme.withAlpha(UiTheme.accent, 60)
            c.drawCircle(px, py, 24f, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = if (hand.pinching) 7f else 3.5f
            p.color = UiTheme.accent
            c.drawCircle(px, py, if (hand.pinching) 12f else 15f, p)
            p.style = Paint.Style.FILL
        }
    }

    private fun drawStatusText(c: Canvas) {
        p.textAlign = Paint.Align.LEFT
        p.color = UiTheme.textPrimary
        p.textSize = 24f
        c.drawText("VR BOX HOME OS", 22f, height * 0.115f, p)
        p.textSize = 16f
        p.color = UiTheme.textSecondary
        c.drawText(status, 22f, height * 0.115f + 24f, p)
        p.textSize = 14f
        p.color = UiTheme.textMuted
        c.drawText(cameraInfo, 22f, height * 0.115f + 45f, p)
    }

    private fun drawToasts(c: Canvas, w: Float, h: Float) {
        val now = SystemClock.uptimeMillis()
        val it = toasts.iterator()
        var any = false
        while (it.hasNext()) {
            val t = it.next()
            val age = now - t.createdAt
            if (age > 2000) { it.remove(); continue }
            any = true
            val fadeIn = min(1f, age / 150f)
            val fadeOut = if (age > 1600) 1f - (age - 1600) / 400f else 1f
            val alpha = (fadeIn * fadeOut * 235).toInt().coerceIn(0, 235)

            val pos = when (t.slot) {
                0 -> RectF(w * 0.66f, h * 0.10f, w * 0.97f, h * 0.16f)
                1 -> RectF(w * 0.03f, h * 0.10f, w * 0.34f, h * 0.16f)
                2 -> RectF(w * 0.66f, h * 0.84f, w * 0.97f, h * 0.90f)
                else -> RectF(w * 0.03f, h * 0.84f, w * 0.34f, h * 0.90f)
            }
            p.color = UiTheme.withAlpha(UiTheme.panelGlassBase, alpha)
            c.drawRoundRect(pos, 20f, 20f, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 1.2f
            p.color = UiTheme.withAlpha(UiTheme.accentSoft, alpha)
            c.drawRoundRect(pos, 20f, 20f, p)
            p.style = Paint.Style.FILL
            p.color = UiTheme.withAlpha(UiTheme.textPrimary, alpha)
            p.textAlign = Paint.Align.CENTER
            p.textSize = 17f
            c.drawText(t.text, pos.centerX(), pos.centerY() + 6f, p)
        }
        if (any) postInvalidateDelayed(60)
    }
}

/** Instância única (lazy) do gerenciador de áudio espacial, evita recriar por frame. */
private object AudioSingleton {
    @Volatile private var instance: SpatialAudioManager? = null
    fun get(context: Context): SpatialAudioManager {
        return instance ?: synchronized(this) {
            instance ?: SpatialAudioManager(context.applicationContext).also { instance = it }
        }
    }
}
