package com.vrbox.home

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class HudState(
    val time: String = "--:--",
    val batteryPct: Int = 100,
    val charging: Boolean = false,
    val wifiConnected: Boolean = false,
    val volumeFrac: Float = 0.5f
)

/**
 * Lê estado real do dispositivo (bateria/wifi/volume/hora) periodicamente
 * e entrega via callback. "Simulado" no sentido de que é uma barra de
 * status própria do app (não a barra do sistema operacional), mas os
 * valores em si são reais quando disponíveis.
 */
class HudManager(private val context: Context, private val onUpdate: (HudState) -> Unit) {

    private val handler = Handler(Looper.getMainLooper())
    private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    private var running = false

    private val tick = object : Runnable {
        override fun run() {
            onUpdate(readState())
            if (running) handler.postDelayed(this, 1000L)
        }
    }

    fun start() {
        if (running) return
        running = true
        handler.post(tick)
    }

    fun stop() {
        running = false
        handler.removeCallbacks(tick)
    }

    fun currentVolumeFraction(): Float {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return 0.5f
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val cur = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        return cur / max.toFloat()
    }

    fun adjustVolume(delta: Int) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        am.adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            if (delta > 0) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
            0
        )
    }

    private fun readState(): HudState {
        val batteryIntent = context.registerReceiver(
            null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        )
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val pct = if (level >= 0 && scale > 0) (level * 100 / scale) else 100
        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        val wifi = runCatching {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        }.getOrDefault(false)

        return HudState(
            time = timeFmt.format(Date()),
            batteryPct = pct,
            charging = charging,
            wifiConnected = wifi,
            volumeFrac = currentVolumeFraction()
        )
    }
}
