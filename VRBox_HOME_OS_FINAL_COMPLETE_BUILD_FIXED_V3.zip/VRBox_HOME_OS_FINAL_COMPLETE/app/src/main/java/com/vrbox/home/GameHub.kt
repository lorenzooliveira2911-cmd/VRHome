package com.vrbox.home

import android.app.Activity
import android.content.Intent

object GameHub {
    data class Game(val name: String, val packageName: String?, val vr: Boolean)

    val games = listOf(
        Game("Roblox VR", RobloxVrBridge.ROBLOX_PACKAGE, true),
        Game("Gorilla Tag VR", "com.AnotherAxiom.GorillaTag", true),
        Game("Minecraft", "com.mojang.minecraftpe", false),
        Game("VRChat", "com.vrchat.mobile", false)
    )

    fun launch(activity: Activity, game: Game): String {
        if (game.packageName == null) return "Jogo sem pacote local"
        val pm = activity.packageManager
        val launch = pm.getLaunchIntentForPackage(game.packageName)
            ?: return "${game.name} não está instalado neste Android"
        activity.startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return if (game.vr) {
            "${game.name} aberto · modo VR depende de OpenXR/runtime compatível"
        } else {
            "${game.name} aberto"
        }
    }
}
