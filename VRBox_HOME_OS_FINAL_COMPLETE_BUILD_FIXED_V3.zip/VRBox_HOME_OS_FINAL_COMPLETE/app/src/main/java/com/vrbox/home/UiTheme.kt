package com.vrbox.home

import android.graphics.Color

/**
 * Paleta e constantes visuais inspiradas no Horizon OS (Meta Quest).
 * Fundos escuros translúcidos + "frosted glass" simulado (várias camadas
 * de alpha sobrepostas, já que Canvas 2D não tem blur real de baixo custo).
 */
object UiTheme {
    // Base
    val bgVoid = Color.rgb(6, 8, 12)
    val panelGlassBase = Color.argb(190, 18, 22, 30)
    val panelGlassHighlight = Color.argb(28, 255, 255, 255)
    val panelGlassRim = Color.argb(70, 120, 200, 255)
    val panelGlassShadow = Color.argb(90, 0, 0, 0)

    // Acento (ciano Quest-like)
    val accent = Color.rgb(90, 225, 255)
    val accentDim = Color.rgb(52, 130, 150)
    val accentSoft = Color.argb(60, 90, 225, 255)

    // Texto
    val textPrimary = Color.rgb(240, 246, 250)
    val textSecondary = Color.rgb(160, 180, 198)
    val textMuted = Color.rgb(110, 128, 145)

    // Estados
    val danger = Color.rgb(255, 96, 96)
    val warning = Color.rgb(255, 190, 90)
    val success = Color.rgb(110, 235, 150)

    // Guardian
    val guardianCalm = Color.rgb(78, 220, 255)
    val guardianAlert = Color.rgb(255, 90, 90)

    // Skybox (ambiente virtual quando passthrough desligado)
    val skyTop = Color.rgb(10, 12, 24)
    val skyBottom = Color.rgb(28, 22, 48)
    val skyGrid = Color.argb(70, 100, 120, 200)

    // Raios / cantos
    const val CORNER_LG = 34f
    const val CORNER_MD = 22f
    const val CORNER_SM = 12f

    fun withAlpha(color: Int, alpha: Int): Int {
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))
    }
}
