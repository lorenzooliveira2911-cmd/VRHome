package com.vrbox.home

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager

/**
 * Launch bridge for Roblox. Roblox VR itself is controlled by Roblox/OpenXR.
 * We never patch or inject code into the Roblox process.
 */
object RobloxVrBridge {
    const val ROBLOX_PACKAGE = "com.roblox.client"

    fun isInstalled(activity: Activity): Boolean = try {
        activity.packageManager.getPackageInfo(ROBLOX_PACKAGE, 0)
        true
    } catch (_: PackageManager.NameNotFoundException) {
        false
    }

    fun launch(activity: Activity): String {
        if (!isInstalled(activity)) return "Roblox não está instalado"
        val intent = activity.packageManager.getLaunchIntentForPackage(ROBLOX_PACKAGE)
            ?: return "Não foi possível abrir o Roblox"
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        activity.startActivity(intent)
        return "Roblox aberto · VR depende do runtime OpenXR do dispositivo"
    }
}
