package com.vrbox.home

import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import kotlin.math.hypot

/** Índices de landmarks do modelo MediaPipe HandLandmarker (21 pontos). */
private object Lm {
    const val WRIST = 0
    const val THUMB_TIP = 4
    const val INDEX_MCP = 5
    const val INDEX_TIP = 8
    const val MIDDLE_MCP = 9
    const val PINKY_MCP = 17
}

/** Estado processado de uma mão, pronto para a UI consumir. */
data class HandState(
    val isLeft: Boolean,
    val wristX: Float,
    val wristY: Float,
    val pointerX: Float,   // ponta do indicador — usada como cursor direto
    val pointerY: Float,
    val rayDirX: Float,    // direção normalizada do laser (wrist -> index tip)
    val rayDirY: Float,
    val pinching: Boolean,
    val pinchStrength: Float, // 0..1, quanto menor a distância polegar/indicador
    val palmUp: Boolean
)

/**
 * Converte o resultado bruto do MediaPipe em [HandState]s utilizáveis
 * pela renderização (menu de palma, raycast, pinça).
 *
 * OBS: os thresholds de "palm up" são heurísticos e podem precisar de
 * calibração fina dependendo do encaixe físico do celular na VR Box
 * (ângulo da lente/câmera em relação aos olhos).
 */
object GestureEngine {

    private const val PINCH_ON_DIST = 0.055f
    private const val PALM_UP_MIN_ELEVATION = 0.62f // pointerY normalizado (0 topo,1 base); mão precisa estar na metade de cima
    private const val PALM_NORMAL_THRESHOLD = 0f

    fun process(result: HandLandmarkerResult?): List<HandState> {
        if (result == null || result.landmarks().isEmpty()) return emptyList()

        val out = ArrayList<HandState>(2)
        val handednessList = runCatching { result.handednesses() }.getOrNull()

        for (i in result.landmarks().indices) {
            val lm = result.landmarks()[i]
            if (lm.size < 21) continue

            val isLeft = handednessList?.getOrNull(i)?.firstOrNull()?.categoryName()
                ?.equals("Left", ignoreCase = true) ?: (i == 0)

            val wrist = lm[Lm.WRIST]
            val indexTip = lm[Lm.INDEX_TIP]
            val thumbTip = lm[Lm.THUMB_TIP]
            val indexMcp = lm[Lm.INDEX_MCP]
            val pinkyMcp = lm[Lm.PINKY_MCP]

            val pinchDist = hypot(
                (indexTip.x() - thumbTip.x()).toDouble(),
                (indexTip.y() - thumbTip.y()).toDouble()
            ).toFloat()
            val pinching = pinchDist < PINCH_ON_DIST
            val pinchStrength = (1f - (pinchDist / PINCH_ON_DIST)).coerceIn(0f, 1f)

            var rayX = indexTip.x() - wrist.x()
            var rayY = indexTip.y() - wrist.y()
            val rayLen = hypot(rayX.toDouble(), rayY.toDouble()).toFloat().coerceAtLeast(0.0001f)
            rayX /= rayLen
            rayY /= rayLen

            val palmUp = detectPalmUp(wrist, indexMcp, pinkyMcp, isLeft) &&
                indexTip.y() < PALM_UP_MIN_ELEVATION

            out.add(
                HandState(
                    isLeft = isLeft,
                    wristX = wrist.x(),
                    wristY = wrist.y(),
                    pointerX = indexTip.x(),
                    pointerY = indexTip.y(),
                    rayDirX = rayX,
                    rayDirY = rayY,
                    pinching = pinching,
                    pinchStrength = pinchStrength,
                    palmUp = palmUp
                )
            )
        }
        return out
    }

    /**
     * Aproxima se a palma está voltada para a câmera (equivalente a "olhar
     * para a palma" no Quest) via produto vetorial wrist->indexMcp x wrist->pinkyMcp.
     * O sinal de Z se inverte conforme a mão (esquerda/direita) por causa da
     * ordem fixa dos landmarks — por isso o sinal esperado depende de [isLeft].
     */
    private fun detectPalmUp(
        wrist: NormalizedLandmark,
        indexMcp: NormalizedLandmark,
        pinkyMcp: NormalizedLandmark,
        isLeft: Boolean
    ): Boolean {
        val v1x = indexMcp.x() - wrist.x()
        val v1y = indexMcp.y() - wrist.y()
        val v1z = indexMcp.z() - wrist.z()
        val v2x = pinkyMcp.x() - wrist.x()
        val v2y = pinkyMcp.y() - wrist.y()
        val v2z = pinkyMcp.z() - wrist.z()

        // produto vetorial v1 x v2, componente Z é a que indica orientação
        // relativa à câmera (plano XY da imagem).
        val crossZ = v1x * v2y - v1y * v2x
        // termo extra usando z para reforçar robustez em ângulos intermediários
        val crossAux = v1z - v2z

        val facingScore = if (isLeft) crossZ - crossAux else -(crossZ - crossAux)
        return facingScore > PALM_NORMAL_THRESHOLD
    }
}
