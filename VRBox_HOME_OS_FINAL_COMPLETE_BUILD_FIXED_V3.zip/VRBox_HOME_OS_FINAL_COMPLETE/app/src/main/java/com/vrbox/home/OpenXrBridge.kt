package com.vrbox.home

import android.app.Activity
import android.util.Log

object OpenXrBridge {
    private const val TAG = "VRBOX_OPENXR"

    init {
        runCatching { System.loadLibrary("vrbox_openxr") }
            .onFailure { Log.w(TAG, "Bridge OpenXR não carregou", it) }
    }

    external fun nativeProbe(activity: Activity): String
    external fun nativeShutdown()

    fun probe(activity: Activity): String = runCatching {
        nativeProbe(activity)
    }.getOrElse { "OpenXR indisponível: ${it.message}" }

    fun shutdown() = runCatching { nativeShutdown() }
}
