package com.vrbox.home

import android.graphics.RectF

/**
 * Estado (dados puros, sem Android View) de uma janela WebView flutuante
 * no espaço 3D simulado. As coordenadas x/y/w/h são normalizadas (0..1)
 * relativas à área de UM olho (metade da tela).
 */
data class SpatialWindow(
    val id: Int,
    var url: String,
    var x: Float,
    var y: Float,
    var w: Float,
    var h: Float,
    var depth: Float = 0.55f,   // 0 = colado no HUD, 1 = bem ao fundo — usado p/ leve parallax/escala
    var title: String = "Pesquisa",
    var focused: Boolean = false
) {
    fun rect(eyeW: Float, eyeH: Float): RectF {
        return RectF(x * eyeW, y * eyeH, (x + w) * eyeW, (y + h) * eyeH)
    }

    /** Retângulo (em px de UM olho) do "handle" de redimensionar, canto inferior direito. */
    fun resizeHandleRect(eyeW: Float, eyeH: Float): RectF {
        val r = rect(eyeW, eyeH)
        val s = 34f
        return RectF(r.right - s, r.bottom - s, r.right + s * 0.3f, r.bottom + s * 0.3f)
    }

    /** Retângulo do botão fechar, canto superior direito da barra de título. */
    fun closeHandleRect(eyeW: Float, eyeH: Float): RectF {
        val r = rect(eyeW, eyeH)
        val titleH = 46f
        return RectF(r.right - titleH, r.top - titleH, r.right, r.top)
    }

    fun titleBarRect(eyeW: Float, eyeH: Float): RectF {
        val r = rect(eyeW, eyeH)
        return RectF(r.left, r.top - 46f, r.right, r.top)
    }
}

private const val MIN_W = 0.22f
private const val MIN_H = 0.22f
private const val MAX_W = 0.92f
private const val MAX_H = 0.85f

/**
 * Controla o conjunto de janelas abertas. Puramente lógico — quem sincroniza
 * as WebViews reais de cada [SpatialWindow] é a MainActivity, observando
 * [windows] após cada operação.
 */
class SpatialWindowManager(private val maxWindows: Int = 4) {

    val windows = ArrayList<SpatialWindow>()
    private var nextId = 1
    var draggingId: Int = -1
        private set
    var resizingId: Int = -1
        private set
    private var dragOffsetX = 0f
    private var dragOffsetY = 0f

    fun canOpenMore(): Boolean = windows.size < maxWindows

    fun open(url: String): SpatialWindow? {
        if (!canOpenMore()) return null
        val cascade = windows.size * 0.035f
        val win = SpatialWindow(
            id = nextId++,
            url = url,
            x = 0.09f + cascade,
            y = 0.16f + cascade,
            w = 0.6f,
            h = 0.58f,
            title = shortTitle(url)
        )
        focus(win.id)
        windows.add(win)
        return win
    }

    fun close(id: Int) {
        windows.removeAll { it.id == id }
        if (draggingId == id) draggingId = -1
        if (resizingId == id) resizingId = -1
    }

    fun closeAll() = windows.clear()

    fun focus(id: Int) {
        windows.forEach { it.focused = (it.id == id) }
        val idx = windows.indexOfFirst { it.id == id }
        if (idx > 0) {
            val w = windows.removeAt(idx)
            windows.add(w) // topo do z-order = último a desenhar
        }
    }

    fun byId(id: Int): SpatialWindow? = windows.firstOrNull { it.id == id }

    /** Retorna a janela mais ao topo cujo corpo contém o ponto (px, dentro de um olho). */
    fun hitTest(px: Float, py: Float, eyeW: Float, eyeH: Float): SpatialWindow? {
        for (i in windows.indices.reversed()) {
            val win = windows[i]
            if (win.titleBarRect(eyeW, eyeH).contains(px, py) ||
                win.rect(eyeW, eyeH).contains(px, py)
            ) return win
        }
        return null
    }

    fun beginDrag(win: SpatialWindow, px: Float, py: Float, eyeW: Float, eyeH: Float) {
        focus(win.id)
        draggingId = win.id
        dragOffsetX = px / eyeW - win.x
        dragOffsetY = py / eyeH - win.y
    }

    fun updateDrag(px: Float, py: Float, eyeW: Float, eyeH: Float) {
        val win = byId(draggingId) ?: return
        win.x = (px / eyeW - dragOffsetX).coerceIn(0f, 1f - win.w)
        win.y = (py / eyeH - dragOffsetY).coerceIn(0f, 1f - win.h)
    }

    fun endDrag() {
        draggingId = -1
    }

    fun beginResize(win: SpatialWindow) {
        focus(win.id)
        resizingId = win.id
    }

    fun updateResize(px: Float, py: Float, eyeW: Float, eyeH: Float) {
        val win = byId(resizingId) ?: return
        val newW = ((px / eyeW) - win.x).coerceIn(MIN_W, MAX_W)
        val newH = ((py / eyeH) - win.y).coerceIn(MIN_H, MAX_H)
        win.w = newW.coerceAtMost(1f - win.x)
        win.h = newH.coerceAtMost(1f - win.y)
    }

    fun endResize() {
        resizingId = -1
    }

    private fun shortTitle(url: String): String {
        return runCatching {
            val host = android.net.Uri.parse(url).host ?: url
            host.removePrefix("www.")
        }.getOrDefault("Janela")
    }
}
