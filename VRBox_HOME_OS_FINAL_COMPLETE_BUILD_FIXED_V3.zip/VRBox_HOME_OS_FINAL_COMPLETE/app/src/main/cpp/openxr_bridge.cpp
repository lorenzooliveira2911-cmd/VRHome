#include <jni.h>
#include <android/log.h>
#include <dlfcn.h>
#include <cstring>
#include <cstdint>
#include <string>
#include <vector>

#define LOG_TAG "VRBOX_OPENXR"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)

using XrFlags64 = uint64_t;
using XrBool32 = uint32_t;
using XrVersion = uint64_t;
using XrSystemId = uint64_t;
using XrResult = int32_t;
using XrStructureType = int32_t;
using XrInstanceCreateFlags = XrFlags64;
using XrInstance = void*;
using PFN_xrVoidFunction = void (*)();
using PFN_xrGetInstanceProcAddr = XrResult (*)(XrInstance, const char*, PFN_xrVoidFunction*);
using PFN_xrCreateInstance = XrResult (*)(const void*, XrInstance*);
using PFN_xrDestroyInstance = XrResult (*)(XrInstance);
using PFN_xrInitializeLoaderKHR = XrResult (*)(const void*);
using PFN_xrEnumerateInstanceExtensionProperties = XrResult (*)(const char*, uint32_t, uint32_t*, void*);
using PFN_xrGetSystem = XrResult (*)(XrInstance, const void*, XrSystemId*);

static constexpr XrResult XR_SUCCESS = 0;
static constexpr XrResult XR_ERROR_RUNTIME_UNAVAILABLE = -51;
static constexpr XrResult XR_TYPE_INSTANCE_CREATE_INFO = 3;
static constexpr XrStructureType XR_TYPE_INSTANCE_CREATE_INFO_ANDROID_KHR = 1000008001;
static constexpr XrStructureType XR_TYPE_LOADER_INIT_INFO_ANDROID_KHR = 1000089000;
static constexpr XrVersion XR_CURRENT_API_VERSION = (1ull << 48); // OpenXR 1.0

// Minimal ABI-compatible structs used only for the OpenXR bootstrap.
struct XrLoaderInitInfoAndroidKHR {
    XrStructureType type;
    const void* next;
    void* applicationVM;
    void* applicationContext;
};

struct XrInstanceCreateInfoAndroidKHR {
    XrStructureType type;
    const void* next;
    void* applicationVM;
    void* applicationActivity;
};

struct XrApplicationInfo {
    char applicationName[128];
    uint32_t applicationVersion;
    char engineName[128];
    uint32_t engineVersion;
    XrVersion apiVersion;
};

struct XrInstanceCreateInfo {
    XrStructureType type;
    const void* next;
    XrInstanceCreateFlags createFlags;
    XrApplicationInfo applicationInfo;
    uint32_t enabledApiLayerCount;
    const char* const* enabledApiLayerNames;
    uint32_t enabledExtensionCount;
    const char* const* enabledExtensionNames;
};

struct XrInstanceProperties {
    XrStructureType type;
    void* next;
    XrVersion runtimeVersion;
    char runtimeName[128];
};

static JavaVM* g_vm = nullptr;
static void* g_loader = nullptr;
static XrInstance g_instance = nullptr;

static std::string resultText(XrResult r) {
    if (r == XR_SUCCESS) return "XR_SUCCESS";
    if (r == XR_ERROR_RUNTIME_UNAVAILABLE) return "XR_ERROR_RUNTIME_UNAVAILABLE";
    return "XR_RESULT(" + std::to_string(r) + ")";
}

static void closeLoader() {
    if (g_loader) {
        dlclose(g_loader);
        g_loader = nullptr;
    }
}

static PFN_xrGetInstanceProcAddr loadGIPA() {
    if (!g_loader) {
        g_loader = dlopen("libopenxr_loader.so", RTLD_NOW | RTLD_LOCAL);
        if (!g_loader) {
            LOGW("libopenxr_loader.so não carregou: %s", dlerror());
            return nullptr;
        }
    }
    return reinterpret_cast<PFN_xrGetInstanceProcAddr>(dlsym(g_loader, "xrGetInstanceProcAddr"));
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_vrbox_home_OpenXrBridge_nativeProbe(JNIEnv* env, jobject, jobject activity) {
    PFN_xrGetInstanceProcAddr gipa = loadGIPA();
    if (!gipa) return env->NewStringUTF("OpenXR loader não disponível");

    PFN_xrInitializeLoaderKHR initLoader = nullptr;
    if (gipa(nullptr, "xrInitializeLoaderKHR", reinterpret_cast<PFN_xrVoidFunction*>(&initLoader)) == XR_SUCCESS && initLoader) {
        XrLoaderInitInfoAndroidKHR info{};
        info.type = XR_TYPE_LOADER_INIT_INFO_ANDROID_KHR;
        info.next = nullptr;
        info.applicationVM = g_vm;
        info.applicationContext = activity;
        XrResult initResult = initLoader(&info);
        LOGI("xrInitializeLoaderKHR: %s", resultText(initResult).c_str());
    }

    // Verify the Android instance extension before enabling it.
    PFN_xrEnumerateInstanceExtensionProperties enumerateExtensions = nullptr;
    if (gipa(nullptr, "xrEnumerateInstanceExtensionProperties",
             reinterpret_cast<PFN_xrVoidFunction*>(&enumerateExtensions)) == XR_SUCCESS && enumerateExtensions) {
        uint32_t count = 0;
        if (enumerateExtensions(nullptr, 0, &count, nullptr) == XR_SUCCESS && count > 0) {
            std::vector<uint8_t> raw(count * 260);
            struct ExtProp {
                XrStructureType type;
                void* next;
                char extensionName[128];
                uint32_t extensionVersion;
            };
            std::vector<ExtProp> props(count);
            for (auto &p : props) { p.type = 2; p.next = nullptr; }
            uint32_t written = 0;
            if (enumerateExtensions(nullptr, count, &written, props.data()) == XR_SUCCESS) {
                bool found = false;
                for (uint32_t i = 0; i < written; ++i) {
                    if (std::strcmp(props[i].extensionName, "XR_KHR_android_create_instance") == 0) {
                        found = true;
                        break;
                    }
                }
                if (!found) return env->NewStringUTF("OpenXR presente, mas XR_KHR_android_create_instance não é suportada");
            }
        }
    }

    const char* ext = "XR_KHR_android_create_instance";
    XrInstanceCreateInfoAndroidKHR androidInfo{};
    androidInfo.type = XR_TYPE_INSTANCE_CREATE_INFO_ANDROID_KHR;
    androidInfo.next = nullptr;
    androidInfo.applicationVM = g_vm;
    androidInfo.applicationActivity = activity;

    XrInstanceCreateInfo ci{};
    ci.type = XR_TYPE_INSTANCE_CREATE_INFO;
    ci.next = &androidInfo;
    ci.createFlags = 0;
    std::strncpy(ci.applicationInfo.applicationName, "VRBox Home OS", sizeof(ci.applicationInfo.applicationName) - 1);
    ci.applicationInfo.applicationVersion = 4;
    std::strncpy(ci.applicationInfo.engineName, "VRBox OpenXR", sizeof(ci.applicationInfo.engineName) - 1);
    ci.applicationInfo.engineVersion = 1;
    ci.applicationInfo.apiVersion = XR_CURRENT_API_VERSION;
    ci.enabledApiLayerCount = 0;
    ci.enabledApiLayerNames = nullptr;
    ci.enabledExtensionCount = 1;
    ci.enabledExtensionNames = &ext;

    PFN_xrCreateInstance createInstance = nullptr;
    if (gipa(nullptr, "xrCreateInstance", reinterpret_cast<PFN_xrVoidFunction*>(&createInstance)) != XR_SUCCESS || !createInstance) {
        return env->NewStringUTF("OpenXR: xrCreateInstance indisponível");
    }

    XrResult createResult = createInstance(&ci, &g_instance);
    if (createResult != XR_SUCCESS || !g_instance) {
        std::string msg = "OpenXR detectado, runtime não iniciou: " + resultText(createResult);
        LOGW("%s", msg.c_str());
        return env->NewStringUTF(msg.c_str());
    }

    XrInstanceProperties props{};
    props.type = 4; // XR_TYPE_INSTANCE_PROPERTIES
    PFN_xrVoidFunction raw = nullptr;
    XrResult propsProc = gipa(g_instance, "xrGetInstanceProperties", &raw);
    if (propsProc == XR_SUCCESS && raw) {
        using PFN_xrGetInstanceProperties = XrResult (*)(XrInstance, XrInstanceProperties*);
        auto getProps = reinterpret_cast<PFN_xrGetInstanceProperties>(raw);
        getProps(g_instance, &props);
    }

    std::string name = props.runtimeName[0] ? props.runtimeName : "runtime OpenXR";
    return env->NewStringUTF(("OpenXR ativo: " + name).c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_com_vrbox_home_OpenXrBridge_nativeShutdown(JNIEnv*, jobject) {
    if (g_instance) {
        PFN_xrGetInstanceProcAddr gipa = loadGIPA();
        if (gipa) {
            PFN_xrDestroyInstance destroy = nullptr;
            if (gipa(g_instance, "xrDestroyInstance", reinterpret_cast<PFN_xrVoidFunction*>(&destroy)) == XR_SUCCESS && destroy) {
                destroy(g_instance);
            }
        }
        g_instance = nullptr;
    }
    closeLoader();
}

jint JNI_OnLoad(JavaVM* vm, void*) {
    g_vm = vm;
    return JNI_VERSION_1_6;
}

void JNI_OnUnload(JavaVM*, void*) {
    closeLoader();
    g_vm = nullptr;
}
