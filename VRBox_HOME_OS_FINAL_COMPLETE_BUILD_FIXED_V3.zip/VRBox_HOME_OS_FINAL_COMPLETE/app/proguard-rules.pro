# Keep MediaPipe native/task classes used reflectively.
-keep class com.google.mediapipe.** { *; }
