# VR Box Home OS FINAL COMPLETE

Este pacote reúne as versões anteriores em um único projeto Android, sem qualquer recurso de compartilhamento por WhatsApp ou servidor Wi-Fi.

## Incluído
- câmera traseira adaptativa;
- MediaPipe Hand Landmarker;
- interação por pinça, sem teclado;
- modo estéreo VR Box;
- HUD/Home/Quick actions;
- Guardian visual;
- navegador WebView em janelas espaciais;
- áudio e feedback háptico;
- giroscópio;
- ponte OpenXR;
- Game Hub;
- lançamento do Roblox instalado;
- perfil Roblox VR/OpenXR;
- catálogo com 32 móveis (7 base + 25 novos);
- PC virtual como ponto de acesso ao Game Hub;
- protótipo Python V2 preservado em legacy/;
- script de build Windows.

## Roblox VR
O Roblox VR oficial usa OpenXR, mas a disponibilidade oficial do Roblox em VR é para headsets Meta Quest/PC VR. O Roblox Android comum não pode ser transformado pelo nosso app em Roblox VR por injeção. Este projeto apenas oferece uma ponte/launcher limpa para o app Roblox e para um runtime OpenXR existente.

Fonte oficial: Roblox Creator Hub, VR usa OpenXR como backend: https://create.roblox.com/docs/production/publishing/vr-guidelines
Fonte oficial: Roblox Meta Quest FAQ: https://en.help.roblox.com/hc/en-us/articles/17810433924628-Meta-Quest-FAQ

## Build
Execute `tools/BUILD_APK.bat` no Windows. O APK esperado será:
`app/build/outputs/apk/debug/app-debug.apk`

O pacote não inclui WhatsApp, servidor de compartilhamento, página HTTP ou mecanismo de envio automático.
